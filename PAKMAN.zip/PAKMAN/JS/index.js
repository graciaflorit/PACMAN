//pixelart

/*
GAMEOVER --> punts:0, tonrar a començar
butó: reinicio
GUANYAR--> canviar de pantalla--> fer mapes nous, variable level, score??, minim 3 pantalles
*/
const muerto = new Audio('../pacman-die.mp3');
const comer = new Audio('');
const poder = new Audio('');


document.addEventListener("DOMContentLoaded",()=>{

    const scoreDisplay = document.getElementById("score");
    const grid = document.querySelector('.grid');
    const levelDisplay = document.getElementById("level")
    const width = 28;
    let score = 0;

        // 0 - puntets
        // 1 - muro
        // 2 - tumbat
        // 3 - poder
        // 4 - blanc
        //fant 1 --> vermell
        // fant 2 -->groc
        // fant 3 --> blau
        //fant 4 --> verd
    
        

    const layout =[ 
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
        1,1,1,0,0,4,4,4,4,0,0,0,0,0,0,0,4,4,4,4,0,0,0,0,1,1,1,1,
        1,1,1,0,1,1,1,0,0,0,0,1,1,1,0,4,1,4,1,1,1,4,1,0,1,1,1,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,4,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,1,0,0,0,1,1,1,1,1,1,0,1,1,1,1,4,0,4,1,1,4,4,1,1,0,1,
        1,0,0,3,0,0,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,1,
        1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1,
        1,0,0,0,0,0,0,1,1,0,0,0,0,1,1,0,3,1,1,0,0,0,0,4,4,0,0,1,
        1,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,1,
        1,1,1,1,1,1,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,
        1,1,1,1,1,1,0,1,1,1,1,1,1,0,0,1,1,1,1,1,1,0,1,1,1,1,1,1,
        1,1,1,1,1,1,0,4,4,1,1,4,4,0,0,4,4,1,1,0,4,0,1,1,1,1,1,1,
        4,4,4,4,4,0,0,0,0,0,0,0,0,4,0,0,0,0,4,4,4,4,0,3,0,0,0,4,
        1,1,1,1,1,1,1,1,1,1,1,0,4,0,4,0,1,1,1,1,1,1,1,1,1,0,1,1,
        1,0,0,0,0,0,0,0,3,0,1,3,0,4,0,0,1,1,0,0,0,0,0,0,0,0,4,1,
        1,1,1,1,1,1,0,1,0,1,1,1,1,1,1,0,1,1,1,1,1,0,1,1,1,1,4,1,
        1,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,1,0,0,0,0,0,0,0,4,1,
        1,1,1,1,1,0,1,1,1,1,0,0,1,1,0,1,1,1,0,1,0,1,1,1,1,1,1,1,
        1,1,1,1,1,0,0,4,4,4,4,0,0,0,0,0,0,0,3,0,0,0,1,1,1,1,1,1,
        1,1,1,1,1,1,0,1,1,0,4,1,1,4,1,1,1,4,4,0,1,0,1,1,1,1,1,1,
        1,1,1,1,1,1,0,1,1,4,4,4,0,0,0,0,1,1,1,1,1,0,1,1,1,1,1,1,
        1,4,4,4,4,0,0,0,0,0,0,0,0,4,4,4,4,4,4,0,0,0,0,0,0,0,0,1,
        1,4,1,1,0,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,0,1,1,1,1,1,0,1,
        1,4,3,0,0,3,0,0,0,4,4,4,0,1,1,0,4,4,4,4,4,4,4,4,0,0,4,1,
        1,1,1,0,1,1,1,1,1,0,1,1,0,0,0,0,0,0,1,0,1,1,1,1,1,1,4,1,
        1,1,1,0,1,1,1,0,0,0,1,1,1,1,1,1,1,1,1,4,4,1,1,1,1,0,0,1,
        1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,0,3,0,0,0,1,
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1
    ];
    const layout1 =[ 
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
        1,0,1,0,0,4,4,4,1,0,0,0,0,0,0,0,4,4,4,4,0,1,0,0,0,0,0,1,
        1,0,4,0,4,4,4,0,1,0,1,1,1,1,1,4,1,4,4,4,4,1,4,0,4,0,1,1,
        1,0,1,1,1,1,1,0,1,0,0,0,0,4,0,1,0,0,0,0,0,1,0,0,0,1,0,1,
        1,0,1,1,0,0,1,4,1,4,4,4,0,4,4,1,1,1,1,1,1,4,4,4,4,1,0,1,
        1,0,1,3,0,0,1,4,1,4,4,0,0,0,0,1,0,0,0,0,1,0,0,0,3,1,0,1,
        1,0,1,1,4,1,1,4,4,4,4,4,0,4,1,1,4,4,4,4,1,0,4,4,4,1,0,1,
        1,0,0,1,0,1,1,1,4,0,0,0,0,4,4,1,3,4,4,0,1,0,0,4,4,1,0,1,
        1,0,0,0,0,3,0,4,4,4,4,1,1,4,4,0,4,4,4,4,1,0,4,4,0,1,4,1,
        1,0,1,4,0,0,0,0,1,0,3,1,1,0,0,0,0,0,0,0,0,0,4,4,0,1,4,1,
        1,0,1,4,4,0,0,4,1,4,4,1,1,0,0,1,0,0,3,1,0,0,4,4,1,0,0,1,
        1,0,1,0,0,3,1,1,1,0,4,1,1,4,4,1,4,4,4,0,4,0,4,1,1,0,4,1,
        1,0,1,4,0,1,1,1,1,4,4,1,1,4,1,1,4,4,4,1,0,4,4,1,4,4,0,1,
        1,0,0,0,0,0,0,4,1,4,4,1,1,0,0,1,4,4,4,1,1,0,4,4,4,4,4,1,
        1,4,1,4,4,0,0,4,1,4,4,1,1,0,0,1,0,0,3,1,1,0,4,4,0,0,0,1,
        1,4,1,1,4,3,0,4,4,0,4,1,1,4,4,1,4,4,4,1,1,0,4,4,4,4,4,1,
        1,4,4,1,4,1,4,1,4,4,0,1,1,4,0,1,4,1,0,1,1,4,4,4,0,0,0,1,
        1,4,1,1,4,1,0,1,1,0,1,1,0,0,0,1,0,1,3,1,1,0,4,1,1,0,0,1,
        1,0,0,0,0,0,3,0,1,0,4,4,4,4,4,1,4,1,4,1,1,4,4,4,1,0,0,1,
        1,0,0,0,0,0,0,0,1,0,4,4,4,4,4,1,4,1,4,1,1,0,4,1,1,4,4,1,
        1,4,1,1,0,0,0,4,1,0,4,4,4,4,4,1,4,1,4,1,1,4,4,1,1,4,4,1,
        1,4,1,1,0,1,1,1,1,0,4,4,4,4,4,1,4,1,4,4,1,4,4,1,1,4,4,1,
        1,4,1,1,0,0,0,0,1,0,4,4,4,4,4,1,4,1,4,4,1,4,4,1,1,4,4,1,
        1,4,1,0,0,0,0,0,1,0,4,4,4,4,4,4,4,1,4,4,1,4,4,1,1,4,4,1,
        1,0,0,0,1,0,0,0,4,0,1,1,1,1,1,4,4,1,4,4,1,1,4,1,1,4,4,1,
        1,0,1,1,1,0,0,0,1,0,4,4,4,4,4,4,4,4,4,4,4,4,1,1,1,4,4,1,
        1,0,0,0,0,0,0,0,1,0,4,4,4,4,4,4,4,1,4,4,4,4,4,1,1,4,4,1,
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1

        ];

        const layout2=[ 
            1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
            1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
            1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1,
            1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1,
            1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1,
            1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 3, 1, 1,
            1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1,
            4, 4, 4, 4, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 4, 4, 4, 1,
            1, 1, 1, 1, 1, 3, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1,
            0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
            1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1,
            4, 4, 4, 4, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 4, 4, 4, 1,
            1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1,
            1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1,
            1, 1, 1, 3, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1,
            1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 1,
            1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1,
            1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 3, 0, 1, 1,
            1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
            1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
            1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1,
            1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
            1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1,
            1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 3, 0, 1, 1,
            1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
            1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1,
            1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
            1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,]

    
    let currentlayout = layout;
    const cuadrados = [];

    function createBoard(layout){
        for(let i=0;i<layout.length;i++){
            const cuadro = document.createElement('div');
            cuadro.id = i;
            grid.appendChild(cuadro);
            cuadrados.push(cuadro);

            if(layout[i] === 0){
                cuadrados[i].classList.add('puntets');
            }
            if(layout[i] === 1){
                cuadrados[i].classList.add('muro');
            }
            if(layout[i] === 2){
                cuadrados[i].classList.add('murotumbat');
            }
            if(layout[i] === 3){
                cuadrados[i].classList.add('poder');
            }
            
            
        }
    }
    createBoard(layout);

    //Create pac-man
    let pacmanIndex = 355;
    cuadrados[pacmanIndex].classList.add('pac-man');
    function movePacman(tecla){
        cuadrados[pacmanIndex].classList.remove('pac-man');
        console.log(tecla)

        //moure amb fleches i que xoqui amb es muro
        if(tecla.key === 'ArrowUp' && !cuadrados[pacmanIndex-width].classList.contains('muro')){
            pacmanIndex -= width;
        }
        if(tecla.key === 'ArrowDown' && !cuadrados[pacmanIndex+width].classList.contains('muro')){
            pacmanIndex += width;
        }
        if(tecla.key === 'ArrowLeft' && !cuadrados[pacmanIndex-1].classList.contains('muro')){
            pacmanIndex -= 1;
            if(pacmanIndex == 336){
                pacmanIndex=363
            }
        }
        if(tecla.key === 'ArrowRight' && !cuadrados[pacmanIndex+1].classList.contains('muro')){
            pacmanIndex += 1;
            if(pacmanIndex == 363){
                pacmanIndex=336
            }
        }
        cuadrados[pacmanIndex].classList.add('pac-man');

        comePunto();
        comePastilla();
        gameOver();
        guanyar();
    }

    function comePunto(){
        if(cuadrados[pacmanIndex].classList.contains('puntets')){
            scoreDisplay.innerHTML = score;
            score ++;
            cuadrados[pacmanIndex].classList.remove('puntets'); 
        }
    }

    function comePastilla(){
        if(cuadrados[pacmanIndex].classList.contains('poder')){
            scoreDisplay.innerHTML = score;
            score +=10;

            ghosts.forEach(fantasma => fantasma.asustat = true);
            setTimeout(relax, 10000);

            cuadrados[pacmanIndex].classList.remove('poder'); 
    
        }
    }
    function relax(){
        ghosts.forEach(fantasma => fantasma.asustat = false);


    }

    class Ghost{
        constructor(className, startIndex, vel){
                this.className = className;
                this.startIndex = this.startIndex
                this. vel = vel;
                this.ghostIndex = startIndex;
                this.asustat = false; 
                this.timerId = NaN;
            }
        }

        ghosts = [
            new Ghost('fant1', 376, 350),
            new Ghost('fant2', 378, 350),
            new Ghost('fant3', 405, 350),
            new Ghost('fant4', 349, 350),
        ]

        console.log(ghosts)

        ghosts.forEach(ghost =>{
            cuadrados[ghost.ghostIndex].classList.add(ghost.className);
            cuadrados[ghost.ghostIndex].classList.add('ghost')
        });
//recorr tots els fantasmes i cada fantasma particular cridarà a moveGhost(ghost)
        ghosts.forEach(ghost => moveGhost(ghost))

        function moveGhost(ghost){
            const directions = [-1, 1, width, -width];
            let direction = directions[Math.floor(Math.random()*directions.length)]; 

            ghost.timerId = setInterval(function(){
                if(!cuadrados[ghost.ghostIndex+direction].classList.contains('muro')
                && !cuadrados[ghost.ghostIndex+direction].classList.contains('ghost')){

                    cuadrados[ghost.ghostIndex].classList.remove(ghost.className, 'ghost', 'fasustado')
                    ghost.ghostIndex += direction;
                    cuadrados[ghost.ghostIndex].classList.add(ghost.className, 'ghost');
                }
                else{
                    direction = directions[Math.floor(Math.random()*directions.length)]
                }

                if(ghost.asustat){
                    cuadrados[ghost.ghostIndex].classList.add(ghost.className, 'fasustado');
                }

                if(ghost.asustat && cuadrados[ghost.ghostIndex].classList.contains('pac-man')){
                    cuadrados[ghost.ghostIndex].classList.remove('fasustado', 'ghost', ghost.className);
                    ghost.ghostIndex = ghost.startIndex;
                    ghost.asustat = false;
                    score +=100;
                    scoreDisplay.innerHTML = score;
                    cuadrados[ghost.ghostIndex].classList.add('ghost', ghost.className);
                }
                },ghost.vel)  
            gameOver(); 
                
    };

    document.addEventListener('keyup', movePacman);

    const restartButton = document.getElementById('buto');
    restartButton.addEventListener('click', ()=> {
    location.reload();
    })
    function gameOver(){
        if(cuadrados[pacmanIndex].classList.contains('ghost')
        && !cuadrados[pacmanIndex].classList.contains('fasustado')){
            ghosts.forEach(f => clearInterval(f.timerId));
            document.addEventListener('keyup', movePacman);
            muerto.play(); 
            setTimeout(function(){
                alert("has perdut")
            },500)
            score = 0;
            moveGhost();
            document.addEventListener('keyup', movePacman);
            

            
        }
    }
    function guanyar(){
        level = 1;
        levelDisplay.innerHTML= level;

        if(score === 200){
            level = 2;
            levelDisplay.innerHTML = level;
            
            cuadrados.forEach(x=>x.classList="");
            ghosts.forEach(f => clearInterval(f.timerId));
            //createBoard(layout1);
            document.removeEventListener('keyup', movePacman)
            document.removeEventListener('keydown', movePacman)

            ghosts.forEach(ghost => {
                cuadrados[ghost.ghostIndex].classList.remove(ghost.className);
                cuadrados[ghost.ghostIndex].classList.remove('ghost');
            });
            cuadrados[pacmanIndex].classList.remove('pacman');

            setTimeout(function(){
                alert("Has guanyat la primera ronda ");
                
                currentlayout = layout1;
                createBoard(currentlayout);
                pacmanIndex = 355;
                cuadrados[pacmanIndex].classList.add('pacman');
                document.addEventListener('keyup', movePacman);
                document.addEventListener('keydown', movePacman);

                ghosts.forEach(ghost =>{
                cuadrados[ghost.ghostIndex].classList.add(ghost.className);
                cuadrados[ghost.ghostIndex].classList.add('ghost')
                });
    //recorr tots els fantasmes i cada fantasma particular cridarà a moveGhost(ghost)
                ghosts.forEach(ghost => moveGhost(ghost))

            },500);
        };
        if(score === 100){
            level = 3;
            levelDisplay.innerHTML = level;
            
            cuadrados.forEach(x=>x.classList="");
            ghosts.forEach(f => clearInterval(f.timerId));
            //createBoard(layout1);
            document.removeEventListener('keyup', movePacman)
            document.removeEventListener('keydown', movePacman)

            ghosts.forEach(ghost => {
                cuadrados[ghost.ghostIndex].classList.remove(ghost.className);
                cuadrados[ghost.ghostIndex].classList.remove('ghost');
            });
            cuadrados[pacmanIndex].classList.remove('pacman');

            setTimeout(function(){
                alert("Has guanyat la primera ronda ");
                
                currentlayout = layout2;
                createBoard(currentlayout);
                pacmanIndex = 355;
                cuadrados[pacmanIndex].classList.add('pacman');
                document.addEventListener('keyup', movePacman);
                document.addEventListener('keydown', movePacman);

                ghosts.forEach(ghost =>{
                    cuadrados[ghost.ghostIndex].classList.add(ghost.className);
                    cuadrados[ghost.ghostIndex].classList.add('ghost')
                });
            //recorr tots els fantasmes i cada fantasma particular cridarà a moveGhost(ghost)
                ghosts.forEach(ghost => moveGhost(ghost))

            },500);
        };
    }
});




